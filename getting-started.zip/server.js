var app = require('./server/server.js')
app.start();
